const jwt = require("jsonwebtoken");

// Middleware  JWT
const authenticateToken = (req, res, next) => {
  try {
    const token = req.header("Authorization");

    if (!token) {
      return res.status(401).json({ 
        error: true, 
        message: "Access denied. No token provided",
        data: null 
      });
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      req.user = decoded;
      next();

    } catch (invalidTokenError) {
      return res.status(401).json({ 
        error: true, 
        message: "Invalid token.",
        data: null 
      });
    }

  } catch (generalError) {
    console.error("Authentication Middleware Error:", generalError);
    res.status(500).json({ 
      error: true, 
      message: "Authentication failed.",
      data: null 
    });
  }
};

module.exports = authenticateToken;