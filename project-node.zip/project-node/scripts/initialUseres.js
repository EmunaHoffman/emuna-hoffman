

module.exports = [
    {
        name: {
            first: "David",
            middle: "",
            last: "Pulke"
        },
        phone: "0501234567",
        email: "davidpolak10201@gmail.com",
        password: "David@12345",
        image: {
            url: "https://cdn.pixabay.com/photo/2025/03/02/21/32/eurasier-aloha-puppy-9442845_640.jpg",
            alt: "some cute animal picture"
        },
        address: {
            state: "Jerusalem",
            country: "israel",
            city: "beit shemesh",
            street: "somewhere",
            houseNumber: "5",
            zip: "9957784"
        },
        isBusiness: true,
        isAdmin: true
    },
    {
        name: {
            first: "Sharon",
            middle: "",
            last: "Something"
        },
        phone: "0505566778",
        email: "sharonsomething123@gmail.com",
        password: "Sharon@12345",
        image: {
            url: "https://archive.org/download/discordprofilepictures/discordgrey.png",
            alt: "discords default icon"
        },
        address: {
            state: "Jerusalem",
            country: "israel",
            city: "petah tikva",
            street: "wonderland",
            houseNumber: "420",
            zip: "336654"
        },
        isBusiness: true,
        isAdmin: false
    },
    {
        name: {
            first: "Ron",
            middle: "",
            last: "Chakabon"
        },
        phone: "0537894856",
        email: "chakabon123@gmail.com",
        password: "Ron@12345",
        image: {
            url: "https://thumbs.dreamstime.com/b/character-cartoon-illustration-male-fantasy-warrior-sword-shotgun-design-hunter-82031423.jpg",
            alt: "male warrior"
        },
        address: {
            state: "Jerusalem",
            country: "israel",
            city: "raanana",
            street: "shithole",
            houseNumber: "2",
            zip: "698569"
        },
        isBusiness: false,
        isAdmin: false
    }
];