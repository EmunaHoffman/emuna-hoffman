const { Schema, model } = require("mongoose");

const userSchema = new Schema({
    firstName: {
        type: String,
        minlength: 2,
        maxlength: 256,
        required: true
    },
    middleName: {
        type: String,
        default: "",
        maxlength: 256
    },
    lastName: {
        type: String,
        minlength: 2,
        maxlength: 256,
        required: true
    },
    phone: {
        type: String,
        minlength: 9,
        maxlength: 11,
        required: true
    },
    email: {
        type: String,
        minlength: 5,
        maxlength: 40,
        required: true,
        unique: true
    },
    password: {
        type: String,
        minlength: 7,
        required: true
    },
    image: {
        type: {
            url: {
                type: String,
                minlength: 14,
                default: ""
            },
            alt: {
                type: String,
                minlength: 2,
                maxlength: 256,
                default: "" 
            },
        },
        default: {}
    },
    address: {
        type: {
            state: {
                type: String,
                minlength: 2,
                maxlength: 256,
                default: ""
            },
            country: {
                type: String,
                required: true,
                minlength: 2,
                maxlength: 256,
                default: "Israel"
            },
            city: {
                type: String,
                required: true,
                minlength: 2,
                maxlength: 256
            },
            street: {
                type: String,
                required: true,
                minlength: 2,
                maxlength: 256
            },
            houseNumber: {
                type: Number,
                required: true,
                min: 1 
            },
            zip: {
                type: String, 
                minlength: 2,
                maxlength: 256,
                default: ""
            },
        },
        default: {}
    },
    isBusiness: {
        type: Boolean,
        required: true,
        default: false
    },
    isAdmin: {
        type: Boolean,
        default: false
    },
    failedLoginAttempts: { 
        type: [Date],
        default: []
    }
}, { timestamps: true });

const User = model("User", userSchema);
module.exports = User;