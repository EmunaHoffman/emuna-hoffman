const { Schema, model, SchemaTypes } = require("mongoose");

const cardSchema = new Schema({
    userId: {
        type: SchemaTypes.ObjectId,
        ref: 'User',
        required: true,
    },
    title: {
        type: String,
        minlength: 2,
        maxlength: 256,
        required: true
    },
    subtitle: {
        type: String,
        minlength: 2,
        maxlength: 256,
        required: true
    },
    description: {
        type: String,
        minlength: 2,
        maxlength: 1024,
        required: true
    },
    phone: {
        type: String,
        minlength: 9,
        maxlength: 11,
        required: true
    },
    email: {
        type: String,
        minlength: 5,
        maxlength: 40,
        required: true,
        unique: true
    },
    web: {
        type: String,
    },
    image: {
        type: {
            url: {
                type: String,
                default: ""
            },
            alt: {
                type: String,
                maxlength: 256,
                default: "" 
            },
        },
        default: {}
    },
    address: {
        type: {
            state: {
                type: String,
                default: ""
            },
            country: {
                type: String,
                required: true,
                default: "Israel"
            },
            city: {
                type: String,
                required: true
            },
            street: {
                type: String,
                required: true
            },
            houseNumber: {
                type: Number,
                required: true
            },
            zip: {
                type: Number,
                default: 0
            },
        },
        default: {}
    },
    likes: {
        type: [SchemaTypes.ObjectId], 
        ref: 'User', 
        default: []
    },
    bizNumber: {
        type: Number,
        unique: true 
    },
}, { timestamps: true });  

const Card = model("Card", cardSchema);
module.exports = Card;