#   Node.js REST API Project - Business Cards Manager

##   Project Description

This project is a server-side REST API designed to manage business cards. It provides functionality for user authentication and authorization, as well as CRUD (Create, Read, Update, Delete) operations on business card resources. The API is built using Node.js, Express.js, and MongoDB.

##   Table of Contents

1.  [Technologies Used](#technologies-used)
2.  [Features](#features)
3.  [API Endpoints](#api-endpoints)
    * [Users](#users)
    * [Cards](#cards)
4.  [Data Structures](#data-structures)
    * [User Object](#user-object)
    * [Card Object](#card-object)
5.  [Installation](#installation)
6.  [Configuration](#configuration)
7.  [Running the Application](#running-the-application)
8.  [Testing](#testing)
9.  [Bonus Features](#bonus-features)
10. [Author](#author)

##   Technologies Used

* Node.js
* Express.js (for building the REST API)
* MongoDB (as the database)
* Mongoose (for MongoDB object modeling)
* bcryptjs (for password hashing)
* jsonwebtoken (for authentication)
* Joi (for data validation)
* morgan (for logging)
* cors (for handling Cross-Origin Resource Sharing)
* dotenv (for managing environment variables)

##   Features

* User Authentication:
    * Registration, login, logout
    * Password hashing
    * JWT-based authentication
* User Management:
    * Admin user role
    * Ability to get, edit, and delete users (with authorization)
    * Changing user business status
* Card Management:
    * CRUD operations on cards
    * Liking cards
* Data Validation:
    * Using Joi to validate request payloads
* Error Handling:
    * Returning appropriate HTTP status codes and error messages
* Logging:
    * Using Morgan for request logging
* Security:
    * Protecting routes with authentication and authorization
* Data Modeling:
    * Using Mongoose to define data schemas

##   API Endpoints

###   Users

####   User Registration

* **Method:** POST
* **URL:** `/users`
* **Authorization:** None
* **Description:** Registers a new user. Requires a unique email address.
* **Request Body:** See [User Object - Create](#user-object-create)
* **Response:** User data (excluding password) and a success message.

####   User Login

* **Method:** POST
* **URL:** `/users/login`
* **Authorization:** None
* **Description:** Logs in a user and returns a JWT.
* **Request Body:** Email and password.
* **Response:** JWT token.

####   Get All Users (Admin Only)

* **Method:** GET
* **URL:** `/users`
* **Authorization:** Admin
* **Description:** Retrieves a list of all users. Only accessible to admin users.
* **Response:** Array of user objects (excluding passwords).

####   Get User by ID

* **Method:** GET
* **URL:** `/users/:id`
* **Authorization:** User or Admin
* **Description:** Retrieves a specific user by their ID. Users can only access their own data. Admins can access any user's data.
* **Response:** User object (excluding password).

####   Update User

* **Method:** PUT
* **URL:** `/users/:id`
* **Authorization:** User
* **Description:** Updates a user's information. Users can only update their own data.
* **Request Body:** See [User Object - Update](#user-object-update)
* **Response:** Updated user object (excluding password).

####   Change User Business Status

* **Method:** PATCH
* **URL:** `/users/:id`
* **Authorization:** User
* **Description:** Changes the `isBusiness` status of a user. Users can only change their own status.
* **Request Body:** `{ "isBusiness": true/false }`
* **Response:** Updated user object (excluding password).

####   Delete User

* **Method:** DELETE
* **URL:** `/users/:id`
* **Authorization:** User or Admin
* **Description:** Deletes a user. Users can delete their own accounts. Admins can delete any user.
* **Response:** Deleted user object.

###   Cards

####   Get All Cards

* **Method:** GET
* **URL:** `/cards`
* **Authorization:** All
* **Description:** Retrieves a list of all cards.
* **Response:** Array of card objects. See [Card Object](#card-object)

####   Get User Cards

* **Method:** GET
* **URL:** `/cards/my-cards`
* **Authorization:** User
* **Description:** Retrieves a list of cards created by the logged-in user.
* **Response:** Array of card objects.

####   Get Card by ID

* **Method:** GET
* **URL:** `/cards/:id`
* **Authorization:** All
* **Description:** Retrieves a specific card by its ID.
* **Response:** Card object.

####   Create Card

* **Method:** POST
* **URL:** `/cards`
* **Authorization:** Business User
* **Description:** Creates a new card. Only business users can create cards.
* **Request Body:** See [Card Object - Create](#card-object-create)
* **Response:** Created card object.

####   Update Card

* **Method:** PUT
* **URL:** `/cards/:id`
* **Authorization:** User (creator)
* **Description:** Updates a card's information. Only the user who created the card can update it.
* **Request Body:** See [Card Object - Update](#card